package Q2OOPTHEORY;

public class Ball {
    private int x=3;
    private int y=4;
    public int getx(){
        return x;
    }
    public int gety(){
        return y;
    }
    public String returnPosition(){
        return "(" + x + "," + y + ")";
    }
    public void updateBallPosition(char direction,Goal g){
        if(direction == 'u' || direction == 'U' && y>0){
            this.x--;
        }
        else if(direction == 'd' || direction == 'D' && y<6){
            this.x++;
        }
        else if(direction == 'l' || direction == 'L' && x<6){
            this.y--;
        }
        else if(direction == 'r' || direction == 'R' && x>0){
            this.y++;
        }

    }
}
