package Q2OOPTHEORY;
import java.util.Scanner;
public class Game {
    Robot r1;
    Robot r2;
    Team t1;
    Team t2;

    public void GameFlow(Goal g, Ground ground,Robot r1,Robot r2,Team t1,Team t2,Ball b) {
        System.out.println("*************************************************************************");
        System.out.println("                   HOW TO PLAY THE ROBOT FOOTBALL GAME                   ");
        System.out.println("*************************************************************************");
        System.out.println("1. There will be two teams each having one robot");
        System.out.println("2. The aim is to kick the ball into a goal");
        System.out.println("3. You can move up/down/left/right only");
        System.out.println("4.Use u to move up d to move down r to move right and l to move left");
        System.out.println("4. Whichever team puts the ball in the goal first wins!");
        System.out.println("************************************************************************8");
        char op;
        Scanner input = new Scanner(System.in);
        System.out.println("Start game?(Y/N) ");
        op = input.next().charAt(0);
        if(op == 'Y' || op == 'y'){
            Play(g,ground,r1,r2,b,t1,t2);
        }
        else if(op == 'N' || op == 'n'){
            //exit
        }
        else{
            //do nothing
        }

    }
    public void DisplayGround(Ground g) {
        String[][] temp = new String[7][7];
        temp=g.getBoundaries();
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                System.out.print(temp[i][j]);
            }
            System.out.print("\n");
        }
    }

    public void TeamTurn(Team t,Ground ground,Robot r,Ball b,Goal g){
        ground.DefineBoundaries(g,r1,r2,b);
       DisplayGround(ground);
       int flag=1;
        char direction='o';
        Scanner in = new Scanner(System.in);
       while(flag==1) {
           System.out.println("**********************************************");
           System.out.println("Team " +t.getName()+" Enter direction (u/d/l/r");
           System.out.println("**********************************************");
           direction = in.next().charAt(0);
           if(direction == 'u' || direction =='U' || direction == 'd' || direction == 'D' || direction == 'l' || direction == 'L' || direction == 'r' || direction == 'R') {
               flag=0; // break out of the while loop
           }
           else{
               System.out.println("Invalid direction (enter 'u/d/l/r')");
           }
       }
       r.hitBall(b,direction,ground.getGoal());
       Boolean ans =ground.getGoal().GoalAchieved(b);
       if(ans==true) {
           System.out.println("Team "+t.getName()+" You win!");
       }
    }

    public void Play(Goal g,Ground ground,Robot r1,Robot r2,Ball b,Team t1,Team t2){
     boolean ans = g.GoalAchieved(b);
     while(!ans){
         TeamTurn(t1,ground,r1,b,g);
         TeamTurn(t2,ground,r2,b,g);
     }



    }
    public void startGame(){
        Scanner scanner = new Scanner(System.in);
        String name1,name2;
        System.out.println("Enter the name  of Robot 1: ");
        name1 = scanner.nextLine();
        System.out.println("Enter the name  of Robot 2: ");
        name2 = scanner.nextLine();
        r1=new Robot(name1,0,0,0);
        r2=new Robot(name2,0,6,6); //initial number of hit for both robot is set to 0
        String team1,team2;
        System.out.println("Enter the team name for robot : "+r1.getName());
        team1 = scanner.nextLine();
        System.out.println("Enter the team name for robot : "+r2.getName());
        team2 = scanner.nextLine();
        t1=new Team(team1,r1);
        t2=new Team(team2,r2);
        Goal goal = new Goal();
        Ball ball = new Ball();
        Ground g= new Ground(goal);
        g.DefineBoundaries(goal,r1,r2,ball);
        int start;
        System.out.println("_________________________________________________");
        System.out.println("Welcome teams "+t1.getName()+"and  "+t2.getName());
        System.out.println("_________________________________________________");
        System.out.println("Enter 1 to view how to play game\nEnter 2 to play game\nEnter 3 to exit game");
        System.out.println("_________________________________________________");
        start = scanner.nextInt();
        scanner.nextLine();
        if(start==1){
         GameFlow(goal,g,r1,r2,t1,t2,ball);
        }
        else if(start==2){
            Play(goal,g,r1,r2,ball,t1,t2);
        }
        else if(start==3){
            //exit
        }
    }











    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Game game = new Game();
        game.startGame();







    }
}
