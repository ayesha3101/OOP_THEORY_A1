package Q2OOPTHEORY;

public class Goal {
    private int xGoal;
    private int yGoal;
    Goal() {
        this.xGoal = 3;
        this.yGoal = 3;
    }
    public int getxGoal() {
        return xGoal;
    }
    public int getyGoal() {
        return yGoal;
    }
    Boolean GoalAchieved(Ball ball) {
        if(ball.getx() == xGoal && ball.gety() == yGoal) {
            return true;
        }
        else {
            return false;
        }
    }

}
