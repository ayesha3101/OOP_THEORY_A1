package Q2OOPTHEORY;
import java.util.Arrays;
public class Ground {
    private String boundaries[][] = new String[7][7]; // goal will be at midpoint
    private Goal goal;  // every football field must have a goal otherwise it does remain a football field

    Ground(Goal goal) {
        this.goal = goal;
    }

    public Goal getGoal() {
        return goal;
    }
    public void DefineBoundaries(Goal goal,Robot r1,Robot r2,Ball b1) {
        for(int i=0;i<7;i++) {
            for(int j=0;j<7;j++) {
                this.boundaries[i][j]="  ";
            }
        }
        for (int i = 0; i < 7; i++) {
            this.boundaries[0][i] = "__";   //defining the boundaries of the ground
            this.boundaries[6][i] = "__";
        }

            this.boundaries[3][3]="G"; //goal of the field
            this.boundaries[b1.getx()][b1.gety()]="B"; //ball
            this.boundaries[r1.getX()][r1.getY()]="r1";  //position initially of robot 1
            this.boundaries[r2.getX()][r2.getY()]="r2";  //position initially of robot 2
    }
    public String[][] getBoundaries() {
        return boundaries;
    }
}

