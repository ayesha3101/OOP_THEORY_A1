package Q2OOPTHEORY;

public class Team {
    private String name;
    private Robot robot;   //A team has a robot
    Team(String name,Robot robot) {
        this.name = name;
        this.robot = robot;   //in order to play a game it is mandatory for a team to have a robot
    }
    public String getName() {
        return name;
    }
    public Robot getRobot() {
        return robot;
    }




}