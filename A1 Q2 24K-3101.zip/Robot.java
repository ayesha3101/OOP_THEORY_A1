package Q2OOPTHEORY;

public class Robot {
    String name;
    int hits;
    int x;
    int y;

    public Robot(String name, int hits,int x, int y) {
        this.name = name;
        this.hits = hits;
        this.x = x;
        this.y = y;
    }
    public String getName() {
        return name;
    }
    public int getHits() {
        return hits;
    }
    public int getX() {
        return x;
    }
    public int getY() {
        return y;
    }
    public void hitBall( Ball b,char direction,Goal g) {
        if(b.getx()==x && b.gety()==y) {
            b.updateBallPosition(direction,g); // when the robot reaches the ball only then can the balls position change
            hits++;
        }
        else if(direction == 'u' || direction == 'U' && y>0){
            this.x--;
        }
        else if(direction == 'd' || direction == 'D' && y<6){
            this.x++;
        }
        else if(direction == 'l' || direction == 'L' && x<6){
            this.y--;
        }
        else if(direction == 'r' || direction == 'R' && x>0){
            this.y++;
        }
        else {
            System.out.println("Invalid direction");
        }
    }
}
