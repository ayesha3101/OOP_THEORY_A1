package Q4OOPTHEORY;

import java.util.ArrayList;
import java.util.Scanner;

public class Student {
    private String name;
    private String id;
    private int age;
    Transport transport;
    Payment payment;
    private String address;
    private String stop;
    boolean paid;

    Student(){
        this.transport = new Transport();
        this.payment = new Payment();
        this.paid = false;
    }

    Student(String name, String id, int age,String address,String stop) {
        this();
        this.name = name;
        this.id = id;
        this.age = age;
        this.address = address;
        this.stop = stop;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public String getAddress() {
        return address;
    }

    public static void registerTransport(Transport transport, ArrayList<Student> students,String id) {
        for (Student student : students) {
          if(student.getId().equals(id)) {
              student.transport = transport;
          }
        }

    }
    public  void payment(Student students,Payment payment) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the date of payment");
        int date = sc.nextInt();
        sc.nextLine();
        System.out.println("Enter the month of payment");
        int month = sc.nextInt();
        sc.nextLine();
        int ans=payment.setDatePayed(date,month);
        if(ans==1){
            students.paid = true;// if deadline is not exceeded paid boolean is set to true & false otherwise as default is false
            System.out.println("Payment paid successfully");
        }

        }

    public void assignVoucher(ArrayList<Payment> payments,Student student){
        for(Payment payment : payments){
            if(payment.isFree){
              student.payment = payment;
                System.out.println("Assigned voucher!");
                break;
            }
        }
    }

}
