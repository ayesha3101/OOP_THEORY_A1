package Q4OOPTHEORY;
import java.util.Scanner;
import java.util.ArrayList;
public class Test{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Transport> t = new ArrayList<>();
        ArrayList<Student> s = new ArrayList<>();
        ArrayList<Payment> p = new ArrayList<>();
        Payment p1 = new Payment(101);
        Payment p2 = new Payment(102);
        Payment p3 = new Payment(103);
        Payment p4 = new Payment(104);
        Payment p5 = new Payment(105);
        Payment p6 = new Payment(106);
        Payment p7 = new Payment(107);
        Payment p8 = new Payment(108);
        Payment p9 = new Payment(109);
        Payment p10 = new Payment(110);
        p.add(p1);
        p.add(p2);
        p.add(p3);
        p.add(p4);
        p.add(p5);
        p.add(p6);
        p.add(p7);
        p.add(p8);
        p.add(p9);
        p.add(p10);
        Transport t1 = new Transport(101, 1, "Gulshan-e-Iqbal", "07:00 AM", "08:00 AM", "Gulshan -> Johar -> Shahrah-e-Faisal -> FAST");
        Transport t2 = new Transport(102, 2, "Defence", "07:15 AM", "08:15 AM", "Defence -> Clifton -> Saddar -> FAST");
        Transport t3 = new Transport(103, 3, "North Nazimabad", "06:45 AM", "07:45 AM", "North Nazimabad -> Nazimabad -> Garden -> FAST");
        Transport t4 = new Transport(104, 4, "Malir", "07:30 AM", "08:30 AM", "Malir -> Model Colony -> Shah Faisal -> FAST");
        Transport t5 = new Transport(105, 5, "Surjani Town", "06:30 AM", "07:30 AM", "Surjani -> Nagan Chowrangi -> Gulshan -> FAST");
        Transport t6 = new Transport(106, 6, "Korangi", "07:10 AM", "08:10 AM", "Korangi -> Landhi -> Shah Faisal -> FAST");
        Transport t7 = new Transport(107, 7, "Bahria Town", "06:15 AM", "07:30 AM", "Bahria -> Super Highway -> University Road -> FAST");
        Transport t8 = new Transport(108, 8, "Lyari", "06:50 AM", "08:00 AM", "Lyari -> Saddar -> MA Jinnah Road -> FAST");
        Transport t9 = new Transport(109, 9, "Johar", "07:20 AM", "08:20 AM", "Johar -> Shahrah-e-Faisal -> FAST");
        Transport t10 = new Transport(110, 10, "Shah Faisal Colony", "07:00 AM", "08:00 AM", "Shah Faisal -> Malir Halt -> Model Colony -> FAST");
        t.add(t1);
        t.add(t2);
        t.add(t3);
        t.add(t4);
        t.add(t5);
        t.add(t6);
        t.add(t7);
        t.add(t8);
        t.add(t9);
        t.add(t10);
        char who;
        System.out.println("Enter t for transporter and s for student");
        who= scanner.next().charAt(0);
        scanner.nextLine();
        if(who == 'S' || who == 's'){
            System.out.println("Enter 1 to view current transports\nEnter 2 to register for transport");
            int option = scanner.nextInt();
            scanner.nextLine();
            if(option == 1){
                Transport.displayTransport(t);
            }
            else if(option == 2){
                String name ;
                String id;
                String address;
                String stop;
                int age;
                System.out.println("Enter your name");
                name = scanner.nextLine();
                System.out.println("Enter your id");
                id = scanner.nextLine();
                System.out.println("Enter your address");
                address = scanner.nextLine();
                System.out.println("Enter your stop");
                stop = scanner.nextLine();
                System.out.println("Enter your age");
                age = scanner.nextInt();
                scanner.nextLine();
                s.add(new Student(name,id,age,address,stop));
                Transport.displayTransport(t);
                int idSelected;
                System.out.println("Enter the transport id for which you want to register");
                idSelected = scanner.nextInt();
                scanner.nextLine();
                for(Transport transport : t){
                    if(transport.getTransportID()==idSelected){
                      Student.registerTransport(transport,s,id);
                    }
                }
                for(Student student : s){
                    if(student.getId().equals(id)){
                        student.assignVoucher(p,student);
                    }
                }
                System.out.println("Do you want to pay your fee voucher now ? (1 for yes 0 for no)");
                int PaymentOption = scanner.nextInt();
                scanner.nextLine();
                if(PaymentOption == 1){
                    for(Student student : s){
                        if(student.getId().equals(id)){
                            student.payment(student,student.payment);
                        }
                    }
                }
                else if(PaymentOption == 0){
                    //do nothing
                }



            }

            else{
                System.out.println("Invalid option");
            }
        }
        else if(who == 'T' || who == 't'){
            System.out.println("Enter 1 to view current transports"
            + "\nEnter 2 to update route plan for transport");
            int option = scanner.nextInt();
            scanner.nextLine();
            if(option == 1){
                Transport.displayTransport(t);
            }
            else if(option == 2){
                Transport.displayTransport(t);
                int idSelected;
                System.out.println("Enter the transport id for which you want to update");
                idSelected = scanner.nextInt();
                scanner.nextLine();
                for(Transport transport : t){
                    if(transport.getTransportID()==idSelected){
                        String newRoute;
                        System.out.println("Enter the new route");
                        newRoute = scanner.nextLine();
                        transport.updateRoutePlan(newRoute);
                        break;
                    }
                }
            }
        }



    }
}