package Q4OOPTHEORY;
import java.util.ArrayList;
public class Payment {
    private int paymentID;
    private double fees;
    private int datePayed;
    private  int MonthPayed;
    private int yearPayed;
    private int deadlineDate;
    private int deadlineMonth;
    boolean isFree;
    ArrayList<Student> StudentsWhoPayed = new ArrayList();
    Payment(){
     this.fees=39000;
     this.yearPayed=2025;
     this.deadlineMonth=2;      //deadline is set to 16/02/2025 payments after that due date will not be accepted
     this.deadlineDate=16;
     this.isFree=true;      //initially all vouchers are free and not assigned to anyone

     //initial charges
    }
    Payment(int paymentID){
        this(); // default constructor called which calls the fee
        this.paymentID = paymentID; //when student wants to generate voucher only display voucherID & fees
    }

    public int getPaymentID() {
        return paymentID;
    }
    public double getFees() {
        return fees;
    }
    public int getDatePayed() {
        return datePayed;
    }