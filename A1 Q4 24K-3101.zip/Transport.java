package Q4OOPTHEORY;

import java.util.ArrayList;

public class Transport {
    private int transportID;
    private int routeNumber;
    private String startLocation;
    private String endLocation;
    private String DepartureTime;
    private String ArrivalTime;
    private String routePlan;



    Transport(){
        this.endLocation="FAST Nuces Karachi";
    }
    Transport(int transportID,int routeNumber,String startLocation,String DepartureTime,String ArrivalTime,String routePlan){
        this();
        this.transportID=transportID;
        this.routeNumber=routeNumber;
        this.startLocation=startLocation;
        this.DepartureTime=DepartureTime;
        this.ArrivalTime=ArrivalTime;
        this.routePlan=routePlan;

    }
    public static void displayTransport(ArrayList<Transport> transports){
        for( Transport tr:transports) {
            System.out.println("Transport ID: " + tr.transportID + " Route Number: " + tr.routeNumber + " Start location: " + tr.startLocation + " End location: " + tr.endLocation);
            System.out.println("Departure Time: " + tr.DepartureTime + " Arrival Time: " + tr.ArrivalTime + " Route Plan: " + tr.routePlan);
            System.out.println();
        }
    }
    public int getTransportID() {
        return transportID;
    }
    public void updateRoutePlan(String routePlan){
        this.routePlan=routePlan;
        System.out.println("updated route plan!");
    }
