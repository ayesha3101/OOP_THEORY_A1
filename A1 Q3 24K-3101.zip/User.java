package Q3OOPTHEORY;
import java.util.ArrayList;
import java.util.Scanner;
public class User {
    private String userID;
    private String licenseType;
    private long phoneNumber;
    private Vehicle v; // assuming the company allows a user to rent one car per ID


    User(String id,String licenseType,long phoneNumber) {
        this.userID = id;
        this.licenseType = licenseType;  //implement a check to see if license type is valid in main
        this.phoneNumber = phoneNumber;
    }
    public String getUserID() {
        return userID;
    }
    public void setUserID(String userID) {
        this.userID = userID;
    }
    public String getLicenseType() {
        return licenseType;
    }
    public void setLicenseType(String licenseType) {
        this.licenseType = licenseType;
    }
    public long getPhoneNumber() {
        return phoneNumber;
    }
    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public Vehicle getV() {
        return v;
    }
    public void DisplayCarsAsPerLicenseType(String userID, String licenseType,ArrayList<Vehicle> v,ArrayList<User> users) {
        for (User u : users) {
            if (u.getUserID().equals(userID)) {
                for (Vehicle vv : v) {
                    if (u.getLicenseType().equals(licenseType)) {
                    }
                }


            }
        }
    }
    // user can only update Phone number and License type ID is unique and can only be set when registering
    public void updatePhoneNumber(long phoneNumber,ArrayList<User> users) {
        Scanner scanner = new Scanner(System.in);
        long newPhoneNumber;
        for(User u : users) {
            if(u.getUserID().equals(userID)) {
                System.out.println("Enter New Phone Number");
                newPhoneNumber = scanner.nextLong();
                u.setPhoneNumber(newPhoneNumber);
                System.out.println("Phone number updated!");
            }
        }
    }
    public void updateLicenseType(String licenseType,ArrayList<User> users) {
        Scanner scanner = new Scanner(System.in);
        String newLicenseType;
        for(User u : users) {
            if(u.getLicenseType().equals(licenseType)) {
                System.out.println("Enter New License Type");
                newLicenseType = scanner.nextLine();
                if(newLicenseType.toLowerCase()=="learner"||newLicenseType.toLowerCase()=="intermediate"||newLicenseType.toLowerCase()=="full"){
                    u.setLicenseType(newLicenseType);
                    break;
                }
            }
        }
    }
    public static boolean isEligible(String LicenseType,ArrayList<Vehicle> v,String Vehicleid) {
        int flag = 0;
        for (Vehicle vv : v) {
            if (vv.getVehicleID().equals(Vehicleid)) {
                for (String eligible : vv.getEligibleFor()) {
                    if (LicenseType.equals(eligible)) {
                        flag = 1;
                        return true;
                    }

                }
                if (flag == 1) {
                    break;
                }
            }
        }
        if (flag == 0) {
            return false;
        } else {
            return true;

        }
    }
    public void rentACar(String LicenseType,ArrayList<Vehicle> v,String Vehicleid,String userID,ArrayList<User> users) {
        boolean ans=isEligible(LicenseType,v,Vehicleid);
        if(ans) {
            for (User u : users) {
                if (u.getUserID().equals(userID)) {
                    for (Vehicle vv : v) {
                        if (vv.getVehicleID().equals(Vehicleid)) {
                            u.v=vv;
                        }
                    }
                }
            }
        }
    }
    public static void register(ArrayList<User> users) {
        Scanner scanner = new Scanner(System.in);
        String userID;
        String licenseType;
        long phoneNumber;
        System.out.println("Enter User ID");
        userID = scanner.nextLine();
        System.out.println("Enter License Type");
        licenseType = scanner.nextLine();
        System.out.println("Enter Phone Number");
        phoneNumber = scanner.nextLong();
        scanner.nextLine();
        users.add(new User(userID,licenseType,phoneNumber));
        System.out.println("User registered!");
    }


}
