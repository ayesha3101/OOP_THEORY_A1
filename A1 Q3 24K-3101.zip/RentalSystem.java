package Q3OOPTHEORY;
import java.util.ArrayList;
import java.util.Scanner;
public class RentalSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Vehicle> availableVehicles = new ArrayList<>();
        ArrayList<User> registeredUsers = new ArrayList<>();
        Vehicle v1 = new Vehicle("VH12345", "Toyota Corolla", 55.99);
        Vehicle v2 = new Vehicle("VH67890", "Honda Civic", 60.50);
        Vehicle v3 = new Vehicle("VH54321", "Ford Focus", 48.75);
        v1.addEligibleFor("intermediate");
        v2.addEligibleFor("full");
        v2.addEligibleFor("learner");
        v3.addEligibleFor("full");
        availableVehicles.add(v1);
        availableVehicles.add(v2);
        availableVehicles.add(v3);
        char who;
        System.out.println("Enter 'u' for user and 'a' for admin");
        who = scanner.next().charAt(0);
        scanner.nextLine();
        if (who == 'u' || who == 'U') {
            int op;
            System.out.println("**************************************");
            System.out.println("        Vehicle rental System");
            System.out.println("**************************************");
            System.out.println("Enter 1 to login");
            System.out.println("Enter 2 to register");
            System.out.println("Enter 3 to exit");
            System.out.println("**************************************");
            op = scanner.nextInt();
            scanner.nextLine();
            if (op == 1) {
                String userID;
                int flag = 1;
                int found = 0;
                System.out.println("Enter your userID");
                userID = scanner.nextLine();
                while (flag == 1) {
                    for (User u : registeredUsers) {
                        if (u.getUserID().equals(userID)) {
                            System.out.println("Login successful");
                            found = 1;
                            break;
                        }
                    }
                    if (found == 0) {
                        System.out.println("Sorry no user with this userID");
                    }


                }

            } else if (op == 2) {
                int what;
                User.register(registeredUsers);
                System.out.println("************************************************************");
                System.out.println("                   WELCOME                   ");
                System.out.println("************************************************************");
                System.out.println("  Enter 1 to view available vehicles");
                System.out.println("  Enter 2 to update details");
                System.out.println("  Enter 3 to see if you are eligible for a specific vehicle");
                System.out.println("  Enter 4 to exit");
                System.out.println("************************************************************");
                what = scanner.nextInt();
                scanner.nextLine();
                if (what == 1) {
                    Vehicle.display(availableVehicles);
                } else if (what == 2) {
                    System.out.println("Enter your userID");
                    String userID = scanner.nextLine();

                } else if (what == 3) {
                    Vehicle.display(availableVehicles);
                    String vehicleID = scanner.nextLine();
                    Boolean ans = false;
                    String UserID = scanner.nextLine();
                    for (User u : registeredUsers) {
                        if (u.getUserID().equals(UserID)) {
                            ans = User.isEligible(u.getLicenseType(), availableVehicles, vehicleID);
                            break;
                        }
                    }
                    if (ans) {
                        System.out.println("You are eligible for a specific vehicle");
                    } else {
                        System.out.println("You are not eligible for a specific vehicle");
                    }
                } else if (what == 4) {
                    // exit
                    // }
                } else if (op == 3) {
                    //exit
                }
            } else if (who == 'a' || who == 'A') {
                System.out.println("**************************************");
                System.out.println("        Vehicle rental System");
                System.out.println("**************************************");
                System.out.println("Enter 1 to view available vehicles");
                System.out.println("Enter 2 to add new vehicle");
                System.out.println("Enter 3 to exit");
                System.out.println("**************************************");
                int op2 = scanner.nextInt();
                scanner.nextLine();
                if (op2 == 1) {
                    Vehicle.display(availableVehicles);
                } else if (op2 == 2) {
                    System.out.println("Enter vehicle ID");
                    String vehicleID = scanner.nextLine();
                    System.out.println("Enter vehicle Model");
                    String vehicleModel = scanner.nextLine();
                    System.out.println("Enter vehicle rent per day");
                    double rentPerDay = scanner.nextDouble();
                    availableVehicles.add(new Vehicle(vehicleID, vehicleModel, rentPerDay));
                    scanner.nextLine();
                    int flag = 1;
                    while (flag == 1) {
                        String types;
                        System.out.println("Enter eligibility types(full,beginner,intermediate)");
                        types = scanner.nextLine();
                        for (Vehicle v : availableVehicles) {
                            if (v.getVehicleID().equals(vehicleID)) {
                                v.addEligibleFor(types);
                                break;
                            }
                        }
                        System.out.println("Do you want to enter more? (1 for yes, 0 for no) ");
                        flag = scanner.nextInt();

                    }
                } else if (op2 == 3) {
                    //exit
                }


            }


        }
    }
}

