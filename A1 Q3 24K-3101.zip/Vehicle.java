package Q3OOPTHEORY;

import java.util.ArrayList;

public class Vehicle {
    private String vehicleID;
   private String Model;
   private double rentPerDay;
   private ArrayList<String> eligibleFor;


   Vehicle(String vehicleID,String Model, double rentPerDay) {
       this.vehicleID = vehicleID;
       this.Model = Model;
       this.rentPerDay = rentPerDay;
       this.eligibleFor = new ArrayList<>();
   }
   public void addEligibleFor(String eligibleFor) {
       this.eligibleFor.add(eligibleFor);
   }
   public static void display(ArrayList<Vehicle> vehicles) {
       for (Vehicle vehicle : vehicles) {
           System.out.println("Model: "+vehicle.Model+" Rent Per Day: "+vehicle.rentPerDay);
           System.out.println("Eligible for:");
           for(String eligibleFor : vehicle.eligibleFor) {
               System.out.print(eligibleFor+" ");
           }
           System.out.println();
       }
   }
   public String getVehicleID() {
       return vehicleID;
   }
   public ArrayList<String> getEligibleFor() {
       return eligibleFor;
   }

}
